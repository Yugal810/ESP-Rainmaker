package com.example.esprainmeter.network

import com.example.esprainmeter.config.UrlHolder
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DynamicUrlInterceptor @Inject constructor() : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        val newUrl = UrlHolder.url.toHttpUrlOrNull()

        if (newUrl != null) {
            val newRequestUrl = request.url.newBuilder()
                .scheme(newUrl.scheme)
                .host(newUrl.host)
                .port(newUrl.port)
                .build()

            request = request.newBuilder()
                .url(newRequestUrl)
                .build()
        }
        return chain.proceed(request)
    }
} 