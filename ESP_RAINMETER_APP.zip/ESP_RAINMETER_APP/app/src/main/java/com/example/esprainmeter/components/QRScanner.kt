package com.example.esprainmeter.components

import android.Manifest
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy // <-- **FIX: ADDED THIS IMPORT**
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.common.util.concurrent.ListenableFuture
import com.google.zxing.*
import com.google.zxing.common.GlobalHistogramBinarizer
import com.google.zxing.common.HybridBinarizer
import kotlinx.coroutines.*
import java.util.concurrent.Executors
import android.util.Size as AndroidSize

@Composable
fun QRScanner(
    onQrCodeScanned: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { granted ->
            hasCameraPermission = granted
        }
    )

    LaunchedEffect(key1 = true) {
        if (!hasCameraPermission) {
            launcher.launch(Manifest.permission.CAMERA)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (hasCameraPermission) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val cameraProviderFuture: ListenableFuture<ProcessCameraProvider> =
                        ProcessCameraProvider.getInstance(ctx)

                    cameraProviderFuture.addListener({
                        val cameraProvider = cameraProviderFuture.get()

                        val preview = Preview.Builder()
                            .setResolutionSelector(
                                ResolutionSelector.Builder().setResolutionStrategy(
                                    ResolutionStrategy(
                                        AndroidSize(1280, 720),
                                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                                    )
                                ).build()
                            )
                            .build()
                            .also { it.setSurfaceProvider(previewView.surfaceProvider) }

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setResolutionSelector(
                                ResolutionSelector.Builder().setResolutionStrategy(
                                    ResolutionStrategy(
                                        AndroidSize(1280, 720),
                                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER
                                    )
                                ).build()
                            )
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()
                            .also {
                                it.setAnalyzer(
                                    Executors.newSingleThreadExecutor(),
                                    QrCodeAnalyzer(onQrCodeScanned)
                                )
                            }

                        try {
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                preview,
                                imageAnalysis
                            )
                        } catch (e: Exception) {
                            Log.e("QRScanner", "Failed to bind camera", e)
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
            QRScannerOverlay()
        } else {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Text("Camera permission is required.")
            }
        }
    }
}

@Composable
fun QRScannerOverlay() {
    val squareSize = 250.dp
    val strokeWidth = 4.dp
    val cornerLength = 40.dp
    val density = LocalDensity.current

    Canvas(modifier = Modifier.fillMaxSize()) {
        val strokeWidthPx = with(density) { strokeWidth.toPx() }
        val cornerLengthPx = with(density) { cornerLength.toPx() }
        val squareSizePx = with(density) { squareSize.toPx() }

        val left = (size.width - squareSizePx) / 2
        val top = (size.height - squareSizePx) / 2
        val right = left + squareSizePx
        val bottom = top + squareSizePx

        // Draw the semi-transparent overlay
        drawRect(color = Color.Black.copy(alpha = 0.5f))

        // Clear the scanning area
        drawRect(
            color = Color.Transparent,
            topLeft = Offset(left, top),
            size = Size(squareSizePx, squareSizePx),
            blendMode = androidx.compose.ui.graphics.BlendMode.Clear
        )

        // Draw the corner brackets
        val cornerColor = Color.White
        // Top-left
        drawLine(cornerColor, Offset(left, top), Offset(left + cornerLengthPx, top), strokeWidthPx)
        drawLine(cornerColor, Offset(left, top), Offset(left, top + cornerLengthPx), strokeWidthPx)
        // Top-right
        drawLine(cornerColor, Offset(right, top), Offset(right - cornerLengthPx, top), strokeWidthPx)
        drawLine(cornerColor, Offset(right, top), Offset(right, top + cornerLengthPx), strokeWidthPx)
        // Bottom-left
        drawLine(cornerColor, Offset(left, bottom), Offset(left + cornerLengthPx, bottom), strokeWidthPx)
        drawLine(cornerColor, Offset(left, bottom), Offset(left, bottom - cornerLengthPx), strokeWidthPx)
        // Bottom-right
        drawLine(cornerColor, Offset(right, bottom), Offset(right - cornerLengthPx, bottom), strokeWidthPx)
        drawLine(cornerColor, Offset(right, bottom), Offset(right, bottom - cornerLengthPx), strokeWidthPx)
    }

    Text(
        text = "Position QR code within the square",
        color = Color.White,
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 32.dp)
            .wrapContentHeight(align = Alignment.Bottom)
    )
}

private const val TAG = "QrCodeAnalyzer"

class QrCodeAnalyzer(
    private val onQrCodeDetected: (String) -> Unit
) : ImageAnalysis.Analyzer {

    private var isProcessing = false
    private var hasDetectedCode = false
    private val analysisScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private val qrReader = MultiFormatReader().apply {
        setHints(mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)))
    }

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) { // <-- **FIX: Type is now resolved**
        if (hasDetectedCode || isProcessing) {
            imageProxy.close()
            return
        }

        isProcessing = true

        analysisScope.launch {
            try {
                val resultText = processAndScanImage(imageProxy)
                if (resultText != null) {
                    handleSuccess(resultText)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error during image analysis", e)
            } finally {
                isProcessing = false
                imageProxy.close()
            }
        }
    }

    @OptIn(ExperimentalGetImage::class)
    private fun processAndScanImage(imageProxy: ImageProxy): String? { // <-- **FIX: Type is now resolved**
        val mediaImage = imageProxy.image ?: return null
        val width = mediaImage.width
        val height = mediaImage.height

        val yData = run {
            val yPlane = mediaImage.planes[0]
            val yBuffer = yPlane.buffer
            val rowStride = yPlane.rowStride
            val data = ByteArray(width * height)

            if (rowStride == width) {
                yBuffer.get(data)
            } else {
                var outputOffset = 0
                for (y in 0 until height) {
                    yBuffer.position(y * rowStride)
                    yBuffer.get(data, outputOffset, width)
                    outputOffset += width
                }
            }
            data
        }

        val source = PlanarYUVLuminanceSource(yData, width, height, 0, 0, width, height, false)

        return try {
            val hybridBitmap = BinaryBitmap(HybridBinarizer(source))
            qrReader.decode(hybridBitmap).text
        } catch (e: NotFoundException) {
            try {
                val globalBitmap = BinaryBitmap(GlobalHistogramBinarizer(source))
                qrReader.decode(globalBitmap).text
            } catch (e: NotFoundException) {
                null
            }
        } catch (e: Exception) {
            null
        } finally {
            qrReader.reset()
        }
    }

    private suspend fun handleSuccess(result: String) = withContext(Dispatchers.Main) {
        if (!hasDetectedCode) {
            hasDetectedCode = true
            Log.i(TAG, "Successfully detected QR code: $result")
            onQrCodeDetected(result)
        }
    }
}