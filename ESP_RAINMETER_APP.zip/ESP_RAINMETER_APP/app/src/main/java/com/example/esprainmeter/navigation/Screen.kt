package com.example.esprainmeter.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object SignUp : Screen("signup")
    object Devices : Screen("devices")
    object QRScanner : Screen("qr_scanner")
    object AddDevice : Screen("add_device")
    object Schedules : Screen("schedules")
    object AddSchedule : Screen("add_schedule")
    object EditSchedule : Screen("edit_schedule")
    object Scenes : Screen("scenes")
    object Settings : Screen("settings")
    object BleProvisioning : Screen("ble_provisioning")
    object SoftApProvisioning : Screen("softap_provisioning")
    object MatterProvisioning : Screen("matter_provisioning")
    object ServerSettings : Screen("server_settings")

    companion object {
        val authScreens = listOf(Login, SignUp, ServerSettings)
        fun fromRoute(route: String?): Screen? {
            return when (route?.substringBefore("/")) {
                Login.route -> Login
                SignUp.route -> SignUp
                Devices.route -> Devices
                QRScanner.route -> QRScanner
                AddDevice.route -> AddDevice
                Schedules.route -> Schedules
                AddSchedule.route -> AddSchedule
                EditSchedule.route -> EditSchedule
                Scenes.route -> Scenes
                Settings.route -> Settings
                BleProvisioning.route -> BleProvisioning
                SoftApProvisioning.route -> SoftApProvisioning
                MatterProvisioning.route -> MatterProvisioning
                ServerSettings.route -> ServerSettings
                else -> null
            }
        }

        fun title(route: String): String {
            return when (fromRoute(route)) {
                Login -> "Login"
                SignUp -> "Sign Up"
                Devices -> "Devices"
                Schedules -> "Schedules"
                Scenes -> "Scenes"
                Settings -> "Settings"
                QRScanner -> "Scan QR Code"
                AddDevice -> "Add Device"
                AddSchedule -> "Add Schedule"
                EditSchedule -> "Edit Schedule"
                BleProvisioning -> "BLE Provisioning"
                SoftApProvisioning -> "SoftAP Provisioning"
                MatterProvisioning -> "Matter Provisioning"
                ServerSettings -> "Server Settings"
                null -> "Rain Meter"
            }
        }

        val mainScreens = listOf(
            Devices,
            Schedules,
            Scenes,
            Settings,
            ServerSettings
        )
    }
} 