package com.example.esprainmeter.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.esprainmeter.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDrawer(
    currentRoute: String,
    navigateToRoute: (String) -> Unit,
    closeDrawer: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    ModalDrawerSheet(modifier = modifier) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "ESP RainMeter",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(16.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Home, contentDescription = "Devices") },
            label = { Text("Devices") },
            selected = currentRoute == Screen.Devices.route,
            onClick = {
                navigateToRoute(Screen.Devices.route)
                closeDrawer()
            },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Schedule, contentDescription = "Schedules") },
            label = { Text("Schedules") },
            selected = currentRoute == Screen.Schedules.route,
            onClick = {
                navigateToRoute(Screen.Schedules.route)
                closeDrawer()
            },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Lightbulb, contentDescription = "Scenes") },
            label = { Text("Scenes") },
            selected = currentRoute == Screen.Scenes.route,
            onClick = {
                navigateToRoute(Screen.Scenes.route)
                closeDrawer()
            },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
            label = { Text("Settings") },
            selected = currentRoute == Screen.Settings.route,
            onClick = {
                navigateToRoute(Screen.Settings.route)
                closeDrawer()
            },
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        Divider(modifier = Modifier.padding(vertical = 16.dp))

        NavigationDrawerItem(
            icon = { Icon(Icons.Default.Logout, contentDescription = "Sign Out") },
            label = { Text("Sign Out") },
            selected = false,
            onClick = {
                onSignOut()
            },
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
    }
} 