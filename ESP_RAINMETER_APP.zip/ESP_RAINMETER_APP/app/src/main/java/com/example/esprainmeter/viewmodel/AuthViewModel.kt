package com.example.esprainmeter.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.esprainmeter.auth.TokenManager
import com.example.esprainmeter.network.AuthApiService
import com.example.esprainmeter.network.TokenResponse
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

sealed class AuthState {
    object Initial : AuthState()
    object Loading : AuthState()
    object Success : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val _authState = MutableStateFlow<AuthState>(AuthState.Initial)
    val authState: StateFlow<AuthState> = _authState

    private val settingsRepository = com.example.esprainmeter.repository.SettingsRepository(context)

    init {
        // Check for saved token on app startup for auto-login
        checkSavedToken()
    }

    private fun checkSavedToken() {
        val savedToken = TokenManager.getToken(context)
        if (!savedToken.isNullOrBlank()) {
            Log.d("AuthViewModel", "Found saved token, auto-login enabled")
            _authState.value = AuthState.Success
        } else {
            Log.d("AuthViewModel", "No saved token found, user needs to login")
            _authState.value = AuthState.Initial
        }
    }

    private fun getRetrofit(): Retrofit {
        val baseUrl = settingsRepository.getServerUrl()
        return Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private fun getAuthApi(): AuthApiService {
        return getRetrofit().create(AuthApiService::class.java)
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val response: TokenResponse = getAuthApi().login(username, password)
                TokenManager.saveToken(context, response.accessToken)
                Log.d("AuthViewModel", "Login successful, token saved")
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Login failed", e)
                _authState.value = AuthState.Error("Login failed: ${e.message}")
            }
        }
    }

    fun logout() {
        TokenManager.clearToken(context)
        _authState.value = AuthState.Initial
    }

    fun signUp(username: String, password: String, email: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val response: TokenResponse = getAuthApi().register(username, email, password)
                // Optionally, save token or just show success
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Sign up failed", e)
                _authState.value = AuthState.Error("Sign up failed: ${e.message}")
            }
        }
    }
}