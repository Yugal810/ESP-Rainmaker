package com.example.esprainmeter.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.esprainmeter.data.Schedule
import com.example.esprainmeter.repository.ScheduleRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlinx.coroutines.flow.asStateFlow

@HiltViewModel
class ScheduleViewModel @Inject constructor(
    private val repository: ScheduleRepository
) : ViewModel() {

    private val _schedules = MutableStateFlow<List<Schedule>>(emptyList())
    val schedules: StateFlow<List<Schedule>> = _schedules.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    init {
        fetchSchedules()
    }

    fun fetchSchedules() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _schedules.value = repository.getSchedules()
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to fetch schedules"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getScheduleById(scheduleId: String): Schedule? {
        return _schedules.value.find { it.id == scheduleId }
    }

    fun addSchedule(schedule: Schedule) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                repository.createSchedule(schedule)
                fetchSchedules() // Refresh the list
                _error.value = null
                android.util.Log.d("ScheduleViewModel", "Schedule added: $schedule")
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to add schedule"
                android.util.Log.e("ScheduleViewModel", "Failed to add schedule: ${e.message}", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun updateSchedule(schedule: Schedule) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                repository.updateSchedule(schedule.id, schedule)
                fetchSchedules() // Refresh the list
                _error.value = null
                android.util.Log.d("ScheduleViewModel", "Schedule updated: $schedule")
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to update schedule"
                android.util.Log.e("ScheduleViewModel", "Failed to update schedule: ${e.message}", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteSchedule(scheduleId: String) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                repository.deleteSchedule(scheduleId)
                fetchSchedules() // Refresh the list
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to delete schedule"
            } finally {
                _isLoading.value = false
            }
        }
    }
} 