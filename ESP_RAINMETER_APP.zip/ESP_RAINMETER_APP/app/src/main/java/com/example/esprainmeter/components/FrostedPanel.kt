package com.example.esprainmeter.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun FrostedPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Int = 16,
    content: @Composable BoxScope.() -> Unit
) {
    val backgroundColor = if (MaterialTheme.colorScheme.isLight()) {
        Color.White.copy(alpha = 0.85f)
    } else {
        Color.White.copy(alpha = 0.1f)
    }
    
    val borderColor = if (MaterialTheme.colorScheme.isLight()) {
        Color.White.copy(alpha = 0.5f)
    } else {
        Color.White.copy(alpha = 0.15f)
    }
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius.dp))
            .background(backgroundColor)
            .border(
                width = 0.5.dp,
                color = borderColor,
                shape = RoundedCornerShape(cornerRadius.dp)
            ),
        content = content
    )
}

// Extension function to check if a color scheme is light or dark
private fun ColorScheme.isLight(): Boolean {
    // A simple heuristic: if the background is closer to white than black, it's light
    val luminance = background.luminance()
    return luminance > 0.5f
}

// Extension function to calculate luminance of a color
private fun Color.luminance(): Float {
    // Standard luminance calculation
    val r = red * 0.299f
    val g = green * 0.587f
    val b = blue * 0.114f
    return r + g + b
}