package com.example.esprainmeter.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.esprainmeter.config.UrlHolder
import com.example.esprainmeter.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    var serverUrl = mutableStateOf(settingsRepository.getServerUrl())
        private set

    fun onUrlChange(newUrl: String) {
        serverUrl.value = newUrl
    }

    fun saveUrl() {
        viewModelScope.launch {
            val url = serverUrl.value
            settingsRepository.setServerUrl(url)
            UrlHolder.url = url
        }
    }
} 