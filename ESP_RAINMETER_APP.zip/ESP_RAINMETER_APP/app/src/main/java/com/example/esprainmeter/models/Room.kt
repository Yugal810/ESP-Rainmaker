package com.example.esprainmeter.models

// This data class represents a room in the smart home system.
// It includes properties for its unique ID, name, and whether it's a default/pre-defined room.
data class Room(
    val id: String?, // Made nullable to be robust against potential nulls from the API
    val name: String = "",           // The name of the room (e.g., "Living Room", "Bedroom")
    val isDefault: Boolean = false   // Indicates if this is a pre-defined default room (true) or user-added (false)
)
