package com.example.esprainmeter.config

object ServerConfig {
    // Change this to your server's IP address
    const val BASE_URL = "http://localhost:8000"  // Local development server

    // API endpoints
    object Endpoints {
        const val LOGIN = "/api/login"
        const val REGISTER = "/api/register"
        const val RAIN_DATA = "/api/rain-data"
        // Add more endpoints as needed
    }
} 