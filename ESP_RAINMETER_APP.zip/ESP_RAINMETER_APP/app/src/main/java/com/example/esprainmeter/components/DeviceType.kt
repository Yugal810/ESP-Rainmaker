package com.example.esprainmeter.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class DeviceType(val icon: ImageVector) {
    TV(Icons.Default.Tv),
    LIGHT(Icons.Default.Lightbulb),
    AC(Icons.Default.AcUnit),
    FAN(Icons.Default.Air), // A more standard icon for Fan
    SOCKET(Icons.Default.Power),
    OTHER(Icons.Default.QuestionMark); // An icon for unknown or custom types

    companion object {
        fun fromString(type: String): DeviceType {
            // Find the corresponding enum entry, or default to OTHER if not found
            return entries.find { it.name.equals(type, ignoreCase = true) } ?: OTHER
        }
    }
}