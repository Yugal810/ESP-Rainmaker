package com.example.esprainmeter.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.State  // Keep this import
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.esprainmeter.models.Device
import com.example.esprainmeter.models.Room
import com.example.esprainmeter.repository.DeviceRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import javax.inject.Inject
import android.util.Log // Add this import
import kotlinx.coroutines.Dispatchers
import com.example.esprainmeter.data.DeviceResponse
import com.example.esprainmeter.data.DeviceStatus
import com.example.esprainmeter.data.NetworkService
import com.example.esprainmeter.config.ServerConfig
import com.example.esprainmeter.network.ApiService
import com.example.esprainmeter.network.DeviceControlRequest
import com.example.esprainmeter.auth.TokenManager
import android.app.Application

sealed class UiState<out T> {
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

@HiltViewModel
class DeviceViewModel @Inject constructor(
    private val deviceRepository: DeviceRepository,
    private val networkService: NetworkService,
    private val apiService: ApiService
) : ViewModel() {

    var token: String = ""

    private val _rooms = MutableStateFlow<List<Room>>(emptyList())
    val rooms: StateFlow<List<Room>> = _rooms.asStateFlow()

    private val _devicesState = MutableStateFlow<UiState<List<Device>>>(UiState.Loading)
    val devicesState: StateFlow<UiState<List<Device>>> = _devicesState.asStateFlow()

    private val _operationError = mutableStateOf<String?>(null)
    val operationError: State<String?> = _operationError

    private val _deviceStatus = MutableStateFlow<DeviceStatus?>(null)
    val deviceStatus: StateFlow<DeviceStatus?> = _deviceStatus.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _devices = MutableStateFlow<List<Device>>(emptyList())
    val devices: StateFlow<List<Device>> = _devices

    // Add caching to prevent excessive API calls
    private var lastRefreshTime = 0L
    private val refreshCooldown = 2000L // 2 seconds cooldown between refreshes

    init {
        Log.d("DeviceViewModel", "ViewModel initialized")
        // Don't automatically fetch data on init - wait for user to be logged in
        // Data will be fetched when refreshData() is called after successful login
    }

    private fun fetchRooms() {
        viewModelScope.launch {
            try {
                val roomList = deviceRepository.getRooms()
                _rooms.value = roomList
            } catch (e: Exception) {
                Log.e("DeviceViewModel", "Error in fetchRooms: ${e.message}", e)
                if (e.message?.contains("Could not validate credentials") == true) {
                    _error.value = "Session expired. Please log in again."
                } else {
                    _error.value = e.message ?: "Failed to fetch rooms"
                }
            }
        }
    }

    fun toggleDeviceState(deviceId: String, newState: Boolean) {
        if (deviceId.isBlank()) {
            _operationError.value = "Cannot control a device with an invalid ID."
            Log.e("DeviceViewModel", "toggleDeviceState called with a blank deviceId.")
            return
        }

        val currentState = _devicesState.value
        if (currentState !is UiState.Success) return

        val originalDevices = currentState.data
        val updatedDevices = originalDevices.map { device ->
            if (device.id == deviceId) {
                device.copy(isOn = newState)
            } else {
                device
            }
        }
        _devicesState.value = UiState.Success(updatedDevices)

        viewModelScope.launch {
            try {
                val action = if (newState) "ON" else "OFF"
                val result = deviceRepository.toggleDeviceState(deviceId, "relay1", action)
                if (result) {
                    Log.d("DeviceViewModel", "Device $deviceId turned ${if (newState) "ON" else "OFF"} successfully")
                } else {
                    _operationError.value = "Failed to control device"
                    _devicesState.value = UiState.Success(originalDevices) // Revert on failure
                    Log.e("DeviceViewModel", "Failed to control device")
                }
            } catch (e: Exception) {
                _operationError.value = "Failed to update device: ${e.message}"
                _devicesState.value = UiState.Success(originalDevices) // Revert on error
                Log.e("DeviceViewModel", "Error toggling device state: ${e.message}", e)
            }
        }
    }

    fun deleteRoom(roomId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                deviceRepository.deleteRoom(roomId)
            } catch (e: Exception) {
                _operationError.value = "Error deleting room: ${e.message}"
            }
        }
    }

    fun deleteEmptyRooms() {
        // This logic requires access to both rooms and devices, making the ViewModel a good place for it.
        viewModelScope.launch {
            if (_devicesState.value is UiState.Success) {
                val devices = (_devicesState.value as UiState.Success<List<Device>>).data
                val roomsToDelete = _rooms.value.filter { room ->
                    !room.isDefault && devices.none { it.roomId == room.id }
                }

                for (room in roomsToDelete) {
                    try {
                        // Safely unwrap the nullable ID. Only proceed if it's not null.
                        room.id?.let { roomId ->
                            deviceRepository.deleteRoom(roomId)
                        }
                    } catch (e: Exception) {
                        _operationError.value = "Failed to delete empty room ${room.name}: ${e.message}"
                    }
                }
            }
        }
    }

    fun setOperationError(message: String) {
        _operationError.value = message
    }

    fun clearOperationError() {
        _operationError.value = null
    }

    fun addRoom(roomName: String) {
        viewModelScope.launch {
            val existingUserRoom = _rooms.value.find { it.name.equals(roomName, ignoreCase = true) }
            if (existingUserRoom != null) {
                _operationError.value = "A room named '$roomName' already exists."
                return@launch
            }
            try {
                deviceRepository.addRoom(roomName)
            } catch (e: Exception) {
                _operationError.value = "Error adding room: ${e.message}"
            }
        }
    }

    suspend fun addDevice(device: Device, roomName: String) {
        try {
            deviceRepository.addDevice(device, roomName)
        } catch (e: Exception) {
            _operationError.value = "Error adding device: ${e.message}"
            throw e // Re-throw to let the UI know the operation failed
        }
    }

    fun deleteDevice(deviceId: String) { // Ensure this function exists
        viewModelScope.launch {
            try {
                deviceRepository.deleteDevice(deviceId)
            } catch (e: Exception) {
                _operationError.value = "Error deleting device: ${e.message}"
                Log.e("DeviceViewModel", "Error deleting device: ${e.message}", e)
            }
        }
    }

    fun initializeAfterLogin() {
        // Check if we're already initializing
        if (_isLoading.value) {
            Log.d("DeviceViewModel", "Initialization already in progress, skipping")
            return
        }
        
        viewModelScope.launch {
            _isLoading.value = true
            try {
                Log.d("DeviceViewModel", "Initializing data after login")
                _devicesState.value = UiState.Loading
                _rooms.value = emptyList() // Clear old rooms
                _devices.value = emptyList() // Clear old devices

                Log.d("DeviceViewModel", "Fetching rooms...")
                fetchRooms()

                Log.d("DeviceViewModel", "Fetching devices...")
                try {
                    val deviceList = deviceRepository.getDevices()
                    Log.d("DeviceViewModel", "Devices fetched successfully: ${deviceList.size} devices")
                    _devicesState.value = UiState.Success(deviceList)
                } catch (e: Exception) {
                    Log.e("DeviceViewModel", "Error fetching devices: ${e.message}", e)
                    _devicesState.value = UiState.Error("Failed to load devices: ${e.message}")
                    _operationError.value = "Failed to load devices: ${e.message}"
                }
            } catch (e: Exception) {
                Log.e("DeviceViewModel", "Error in initialization: ${e.message}", e)
                _devicesState.value = UiState.Error("Failed to initialize: ${e.message}")
                _operationError.value = "Failed to initialize: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun refreshData() {
        Log.d("DeviceViewModel", "Refreshing data")
        
        // Check if we're already refreshing or if too little time has passed
        val currentTime = System.currentTimeMillis()
        if (_isLoading.value) {
            Log.d("DeviceViewModel", "Refresh already in progress, skipping")
            return
        }
        
        if (currentTime - lastRefreshTime < refreshCooldown) {
            Log.d("DeviceViewModel", "Refresh cooldown active, skipping")
            return
        }
        
        lastRefreshTime = currentTime
        
        viewModelScope.launch {
            _isLoading.value = true
            try {
                // Check if user is logged in
                val token = deviceRepository.getTokenOrNull()
                if (token.isNullOrBlank()) {
                    Log.w("DeviceViewModel", "No token found, skipping refresh")
                    _devicesState.value = UiState.Error("Please log in to view devices")
                    return@launch
                }

                _devicesState.value = UiState.Loading
                _rooms.value = emptyList() // Clear old rooms before fetching
                _devices.value = emptyList() // Clear old devices before fetching
                Log.d("DeviceViewModel", "Setting loading state and clearing old data")

                // Fetch rooms first
                val roomList = deviceRepository.getRooms()
                _rooms.value = roomList

                // Then fetch devices
                val deviceList = deviceRepository.getDevices()
                _devices.value = deviceList
                _devicesState.value = UiState.Success(deviceList)
            } catch (e: Exception) {
                Log.e("DeviceViewModel", "Error during refresh: ${e.message}", e)
                if (e.message?.contains("Could not validate credentials") == true) {
                    _devicesState.value = UiState.Error("Session expired. Please log in again.")
                    _operationError.value = "Session expired. Please log in again."
                } else {
                    _devicesState.value = UiState.Error("Failed to refresh: ${e.message}")
                    _operationError.value = "Failed to refresh: ${e.message}"
                }
            } finally {
                _isLoading.value = false
            }
        }
    }

    private suspend fun syncDeviceStatesWithServer(devices: List<Device>) {
        Log.d("DeviceViewModel", "Attempting to sync ${devices.size} devices with server")
        
        try {
            // Get all devices status from server
            val response = apiService.api.getAllDevicesStatus()
            
            if (response.isSuccessful) {
                val serverDevices = response.body()?.devices ?: emptyList()
                val serverDeviceMap = serverDevices.associateBy { it.device_id }
                
                // Update local device states based on server data
                devices.forEach { localDevice ->
                    val serverDevice = serverDeviceMap[localDevice.id]
                    if (serverDevice != null) {
                        val serverState = serverDevice.state == "ON"
                        if (localDevice.isOn != serverState) {
                            Log.d("DeviceViewModel", "Syncing device ${localDevice.name} state from ${localDevice.isOn} to $serverState")
                            deviceRepository.toggleDeviceState(localDevice.id, "relay1", if (serverState) "ON" else "OFF")
                        }
                    }
                }
                
                // Refresh the devices list to show updated states
                loadDevices()
            } else {
                Log.w("DeviceViewModel", "Failed to get devices status from server: ${response.message()}")
            }
        } catch (e: Exception) {
            Log.e("DeviceViewModel", "Error syncing device states: ${e.message}", e)
        }
    }

    fun updateServerUrl(url: String) {
        // Update the URL in SettingsRepository instead of ServerConfig
        // ServerConfig.BASE_URL is a constant, we should use SettingsRepository
        // This method should be updated to work with the SettingsRepository
        // For now, we'll just refresh device status
        getDeviceStatus()
    }

    fun getDeviceStatus() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                val token = deviceRepository.getTokenOrNull() ?: throw Exception("No token found")
                _deviceStatus.value = networkService.getDeviceStatus("Bearer $token")
                _error.value = null
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to get device status"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun turnOnDevice() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                val token = deviceRepository.getTokenOrNull() ?: throw Exception("No token found")
                val response = networkService.turnOnDevice("Bearer $token")
                if (response.success) {
                    getDeviceStatus() // Refresh status
                } else {
                    _error.value = response.message
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to turn on device"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun turnOffDevice() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                val token = deviceRepository.getTokenOrNull() ?: throw Exception("No token found")
                val response = networkService.turnOffDevice("Bearer $token")
                if (response.success) {
                    getDeviceStatus() // Refresh status
                } else {
                    _error.value = response.message
                }
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to turn off device"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun toggleDevice(device: Device) {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                
                // Get token for API call
                val token = deviceRepository.getTokenOrNull() ?: throw Exception("No token found")
                
                // Call the API to control the device
                val newState = !device.isOn
                val action = if (newState) "ON" else "OFF"
                
                val response = apiService.api.controlDevice(
                    DeviceControlRequest(
                        device_id = device.id,
                        relay = "relay1",
                        action = action
                    ),
                    "Bearer $token"
                )

                if (response.isSuccessful) {
                    // Update local state
                    deviceRepository.toggleDeviceState(device.id, "relay1", action)
                    // Refresh devices list
                    loadDevices()
                    Log.d("DeviceViewModel", "Device ${device.name} toggled to ${if (newState) "ON" else "OFF"}")
                } else {
                    _operationError.value = "Failed to control device: ${response.message()}"
                    Log.e("DeviceViewModel", "Server error: ${response.message()}")
                }
            } catch (e: Exception) {
                _operationError.value = "Error controlling device: ${e.message}"
                Log.e("DeviceViewModel", "Error toggling device: ${e.message}", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun loadDevices() {
        viewModelScope.launch {
            try {
                val deviceList = deviceRepository.getDevices()
                _devices.value = deviceList
            } catch (e: Exception) {
                _operationError.value = "Error loading devices: ${e.message}"
            }
        }
    }

    fun testServerConnection() {
        viewModelScope.launch {
            try {
                _isLoading.value = true
                _error.value = null
                
                // Try to get all devices status as a connection test
                val response = apiService.api.getAllDevicesStatus()
                
                if (response.isSuccessful) {
                    Log.d("DeviceViewModel", "Server connection test successful")
                    _operationError.value = null
                } else {
                    _error.value = "Server connection failed: ${response.message()}"
                    Log.e("DeviceViewModel", "Server connection test failed: ${response.message()}")
                }
            } catch (e: Exception) {
                _error.value = "Connection error: ${e.message}"
                Log.e("DeviceViewModel", "Server connection test error: ${e.message}", e)
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearRooms() {
        _rooms.value = emptyList()
    }

    fun addDevice(deviceId: String, deviceName: String, roomId: String) {
        viewModelScope.launch {
            try {
                val success = deviceRepository.addDevice(deviceId, deviceName, roomId)
                if (success) {
                    refreshData()
                } else {
                    _operationError.value = "Failed to add device. Please try again."
                }
            } catch (e: Exception) {
                _operationError.value = "An error occurred: ${e.message}"
            }
        }
    }

    fun deleteDevice(deviceId: String?) {
        if (deviceId.isNullOrBlank()) {
            _operationError.value = "Invalid device ID"
            return
        }
        viewModelScope.launch {
            try {
                deviceRepository.deleteDevice(deviceId)
                refreshData() // Refresh the list after deletion
            } catch (e: Exception) {
                _operationError.value = "Error deleting device: ${e.message}"
            }
        }
    }
}

