package com.example.esprainmeter.repository

import com.example.esprainmeter.data.NetworkService
import com.example.esprainmeter.data.Schedule
import com.example.esprainmeter.auth.TokenManager
import android.content.Context
import javax.inject.Inject
import javax.inject.Singleton
import dagger.hilt.android.qualifiers.ApplicationContext

@Singleton
class ScheduleRepository @Inject constructor(
    private val networkService: NetworkService,
    @ApplicationContext private val context: Context
) {
    suspend fun getSchedules(): List<Schedule> {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        return networkService.getSchedules("Bearer $token")
    }

    suspend fun createSchedule(schedule: Schedule): Schedule {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        return networkService.createSchedule(schedule, "Bearer $token")
    }

    suspend fun updateSchedule(id: String, schedule: Schedule): Schedule {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        return networkService.updateSchedule(id, schedule, "Bearer $token")
    }

    suspend fun deleteSchedule(id: String) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        networkService.deleteSchedule(id, "Bearer $token")
    }

    suspend fun getScheduleById(id: String): Schedule {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        return networkService.getScheduleById(id, "Bearer $token")
    }
} 