package com.example.esprainmeter.models

data class Schedule(
    val id: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val time: String = "", // e.g., "14:30"
    val days: List<String> = emptyList(), // e.g., ["MON", "WED", "FRI"]
    val enabled: Boolean = true
)