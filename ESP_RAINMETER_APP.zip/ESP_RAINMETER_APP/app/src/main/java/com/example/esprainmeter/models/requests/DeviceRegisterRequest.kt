package com.example.esprainmeter.models.requests

data class DeviceRegisterRequest(
    val device_id: String,
    val device_name: String,
    val room_name: String
) 