package com.example.esprainmeter.repository

import com.example.esprainmeter.models.Device
import com.example.esprainmeter.models.Room
import com.example.esprainmeter.network.ApiService
import com.example.esprainmeter.network.DeviceAddRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton
import com.example.esprainmeter.auth.TokenManager
import android.content.Context
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import dagger.hilt.android.qualifiers.ApplicationContext
import com.example.esprainmeter.models.requests.DeviceRegisterRequest

@Singleton
class DeviceRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private fun getApiService(): ApiService.Api {
        val settingsRepository = com.example.esprainmeter.repository.SettingsRepository(context)
        val baseUrl = settingsRepository.getServerUrl()
        val retrofit = retrofit2.Retrofit.Builder()
            .baseUrl(if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/")
            .addConverterFactory(retrofit2.converter.gson.GsonConverterFactory.create())
            .build()
        return retrofit.create(com.example.esprainmeter.network.ApiService.Api::class.java)
    }

    // --- Room Operations ---

    suspend fun getRooms(): List<Room> = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val response = getApiService().getRooms("Bearer $token")
        if (response.isSuccessful) {
            response.body() ?: emptyList()
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to fetch rooms")
        }
    }

    suspend fun addRoom(roomName: String): Boolean = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val response = getApiService().addRoom(Room(id = null, name = roomName), "Bearer $token")
        if (response.isSuccessful) {
            true
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to add room")
        }
    }

    suspend fun deleteRoom(roomName: String): Boolean = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val response = getApiService().deleteRoom(roomName, "Bearer $token")
        if (response.isSuccessful) {
            true
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to delete room")
        }
    }

    // --- Device Operations ---

    suspend fun getDevices(): List<Device> = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val response = getApiService().getAllDevices("Bearer $token")
        if (response.isSuccessful) {
            response.body() ?: emptyList()
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to fetch devices")
            }
    }

    suspend fun addDevice(device: Device, roomName: String): Boolean = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val request = DeviceAddRequest(
            device_id = device.id,
            device_name = device.name,
            room_name = roomName,
            type = device.type,
            qr_value = device.qrValue
        )
        val response = getApiService().addDevice(request, "Bearer $token")
        if (response.isSuccessful) {
            true
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to add device")
        }
    }

    suspend fun deleteDevice(deviceId: String): Boolean = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val response = getApiService().deleteDevice(deviceId, "Bearer $token")
        if (response.isSuccessful) {
            true
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to delete device")
        }
    }

    suspend fun toggleDeviceState(deviceId: String, relay: String, action: String): Boolean = withContext(Dispatchers.IO) {
        val token = TokenManager.getToken(context) ?: throw Exception("No token found")
        val response = getApiService().controlDevice(
            com.example.esprainmeter.network.DeviceControlRequest(
                device_id = deviceId,
                relay = relay,
                action = action
            ),
            "Bearer $token"
        )
        if (response.isSuccessful) {
            true
        } else {
            throw Exception(response.errorBody()?.string() ?: "Failed to control device")
        }
    }

    // Helper to get token or null for ViewModel
    fun getTokenOrNull(): String? = TokenManager.getToken(context)

    suspend fun addDevice(deviceId: String, deviceName: String, roomId: String): Boolean {
        val request = DeviceRegisterRequest(device_id = deviceId, device_name = deviceName, room_name = roomId)
        val response = getApiService().addDevice(request, "Bearer ${TokenManager.getToken(context)}")
        return response.isSuccessful
    }

    suspend fun deleteDevice(deviceId: String) {
        apiService.deleteDevice(deviceId)
    }
}

// Add this helper for OkHttpClient with token
fun getAuthOkHttpClient(context: Context): OkHttpClient {
    return OkHttpClient.Builder()
        .addInterceptor { chain: Interceptor.Chain ->
            val token = TokenManager.getToken(context)
            val request: Request = if (token != null) {
                chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .build()
            } else {
                chain.request()
            }
            chain.proceed(request)
        }
        .build()
}
