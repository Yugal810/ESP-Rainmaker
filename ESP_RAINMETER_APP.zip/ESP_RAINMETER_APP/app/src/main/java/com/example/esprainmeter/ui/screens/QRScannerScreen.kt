package com.example.esprainmeter.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.esprainmeter.components.QRScanner
import com.example.esprainmeter.navigation.Screen
import java.net.URLEncoder
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.rememberCoroutineScope
import com.example.esprainmeter.viewmodel.DeviceViewModel
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QRScannerScreen(navController: NavController, deviceViewModel: DeviceViewModel = hiltViewModel()) {
    var scannedQrCode by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(scannedQrCode) {
        scannedQrCode?.let { qrCode ->
            when {
                isIpOrUrl(qrCode) -> {
                    val formattedUrl = formatUrl(qrCode)
                    deviceViewModel.updateServerUrl(formattedUrl)
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Server IP set to $formattedUrl")
                    }
                    navController.popBackStack()
                }
                isValidDeviceCode(qrCode) -> {
                    val encodedQrCode = URLEncoder.encode(qrCode, "UTF-8")
                    navController.navigate("${Screen.AddDevice.route}/$encodedQrCode")
                }
                else -> {
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Unsupported QR code")
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Scan QR Code") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    FilledIconButton(
                        onClick = { navController.navigate(Screen.BleProvisioning.route) },
                        label = { Text("BLE") },
                        icon = { Icon(Icons.Default.Bluetooth, contentDescription = "BLE") }
                    )
                    FilledIconButton(
                        onClick = { navController.navigate(Screen.SoftApProvisioning.route) },
                        label = { Text("SoftAP") },
                        icon = { Icon(Icons.Default.Wifi, contentDescription = "SoftAP") }
                    )
                    FilledIconButton(
                        onClick = { navController.navigate(Screen.MatterProvisioning.route) },
                        label = { Text("Matter") },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Matter") }
                    )
                }
            }
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            QRScanner(onQrCodeScanned = { qrCode ->
                scannedQrCode = qrCode
            })
        }
    }
}

@Composable
fun FilledIconButton(
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    icon: @Composable () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(8.dp)
    ) {
        FilledIconButton(onClick = onClick) {
            icon()
        }
        label()
    }
}

// Helper to check if the QR code is an IP or URL
fun isIpOrUrl(value: String): Boolean {
    val ipRegex = Regex("""^(http[s]?://)?(\d{1,3}\.){3}\d{1,3}(:\d+)?/?$""")
    return ipRegex.matches(value.trim())
}

// Helper to format the URL
fun formatUrl(value: String): String {
    var url = value.trim()
    if (!url.startsWith("http")) url = "http://$url"
    if (!url.endsWith("/")) url += "/"
    return url
}

// Helper to check if the QR code is a valid device code
fun isValidDeviceCode(value: String): Boolean {
    // Accept only codes starting with DEV- or a UUID pattern
    return value.startsWith("DEV-") || value.matches(Regex("^[0-9a-fA-F-]{36}$"))
}