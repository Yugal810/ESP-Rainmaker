package com.example.esprainmeter.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.esprainmeter.ui.screens.*
import com.example.esprainmeter.viewmodel.AuthViewModel
import com.example.esprainmeter.viewmodel.AuthState
import com.example.esprainmeter.viewmodel.DeviceViewModel

@Composable
fun NavGraph(
    navController: NavHostController,
    authViewModel: AuthViewModel,
    deviceViewModel: DeviceViewModel
) {
    val authState by authViewModel.authState.collectAsState()

    NavHost(
        navController = navController,
        startDestination = if (authViewModel.isLoggedIn()) Screen.Devices.route else Screen.Login.route,
        enterTransition = { fadeIn(animationSpec = tween(300)) },
        exitTransition = { fadeOut(animationSpec = tween(300)) }
    ) {
        composable(route = Screen.Login.route) {
            LoginScreen(
                authState = authState,
                onLogin = { email: String, password: String ->
                    authViewModel.login(email, password)
                },
                onSignUp = {
                    navController.navigate(Screen.SignUp.route)
                },
                onForgotPassword = { /* Not implemented */ },
                onLoginSuccess = {
                    navController.navigate(Screen.Devices.route) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                },
                onNavigateToServerSettings = {
                    navController.navigate(Screen.ServerSettings.route)
                },
                onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) }
            )
        }

        composable(route = Screen.SignUp.route) {
            SignUpScreen(
                authState = authState,
                onSignUp = { email: String, password: String, username: String ->
                    authViewModel.signUp(username, password, email)
                },
                onSignUpSuccess = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.SignUp.route) { inclusive = true }
                    }
                },
                onNavigateBack = {
                    navController.navigateUp()
                }
            )
        }

        composable(route = Screen.QRScanner.route) {
            QRScannerScreen(navController = navController)
        }

        // --- FIX IS HERE ---
        // The route now includes the argument placeholder to match the navigation call.
        composable(
            route = "${Screen.AddDevice.route}/{qrCodeValue}",
            arguments = listOf(navArgument("qrCodeValue") { type = NavType.StringType })
        ) { backStackEntry ->
            val qrCodeValue = backStackEntry.arguments?.getString("qrCodeValue")
            AddDeviceScreen(
                navController = navController,
                qrCode = qrCodeValue,
                deviceViewModel = deviceViewModel
            )
        }
        // --- END OF FIX ---

        composable(route = Screen.BleProvisioning.route) {
            BleProvisioningScreen(navController = navController)
        }

        composable(route = Screen.SoftApProvisioning.route) {
            SoftApProvisioningScreen(navController = navController)
        }

        composable(route = Screen.MatterProvisioning.route) {
            MatterProvisioningScreen(navController = navController)
        }

        composable(route = Screen.Devices.route) {
            DevicesScreen(
                navController = navController,
                deviceViewModel = deviceViewModel
            )
        }

        composable(route = Screen.Schedules.route) {
            SchedulesScreen(
                navController = navController,
                deviceViewModel = deviceViewModel
            )
        }

        composable(route = Screen.Scenes.route) {
            ScenesScreen(
                onNavigateBack = {
                    navController.navigateUp()
                }
            )
        }

        composable(route = Screen.Settings.route) {
            SettingsScreen(
                navController = navController,
                authViewModel = authViewModel,
                onScanQrCode = { /* This will need a new implementation if required */ }
            )
        }

        composable(route = Screen.ServerSettings.route) {
            val currentRoute = navController.currentBackStackEntry?.destination?.route
            val fromLogin = currentRoute == Screen.Login.route || navController.previousBackStackEntry?.destination?.route == Screen.Login.route
            ServerSettingsScreen(
                showBackToLogin = fromLogin,
                onBackToLogin = if (fromLogin) { { navController.popBackStack(Screen.Login.route, inclusive = false) } } else null
            )
        }

        composable(route = Screen.AddSchedule.route) {
            AddScheduleScreen(
                scheduleId = null,
                onNavigateBack = {
                    navController.navigateUp()
                },
                deviceViewModel = deviceViewModel
            )
        }

        composable(
            route = Screen.EditSchedule.route + "/{scheduleId}",
            arguments = listOf(navArgument("scheduleId") { type = NavType.StringType })
        ) { backStackEntry ->
            AddScheduleScreen(
                scheduleId = backStackEntry.arguments?.getString("scheduleId"),
                onNavigateBack = {
                    navController.navigateUp()
                },
                deviceViewModel = deviceViewModel
            )
        }
    }

    LaunchedEffect(authState, navController) {
        when (authState) {
            is AuthState.Success -> {
                // Initialize device data after successful login
                deviceViewModel.initializeAfterLogin()
                
                if (Screen.fromRoute(navController.currentDestination?.route) in Screen.authScreens) {
                    navController.navigate(Screen.Devices.route) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                }
            }
            is AuthState.Initial -> {
                val currentScreen = Screen.fromRoute(navController.currentDestination?.route)
                if (currentScreen !in Screen.authScreens) {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                }
            }
            else -> { /* No-op */ }
        }
    }
}