package com.example.esprainmeter.data

import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path
import retrofit2.http.Header

interface NetworkService {
    @GET("schedules")
    suspend fun getSchedules(@Header("Authorization") token: String): List<Schedule>

    @POST("schedules")
    suspend fun createSchedule(@Body schedule: Schedule, @Header("Authorization") token: String): Schedule

    @PUT("schedules/{id}")
    suspend fun updateSchedule(@Path("id") id: String, @Body schedule: Schedule, @Header("Authorization") token: String): Schedule

    @DELETE("schedules/{id}")
    suspend fun deleteSchedule(@Path("id") id: String, @Header("Authorization") token: String)

    @GET("schedules/{id}")
    suspend fun getScheduleById(@Path("id") id: String, @Header("Authorization") token: String): Schedule

    // Device control endpoints
    @POST("device/on")
    suspend fun turnOnDevice(@Header("Authorization") token: String): DeviceResponse

    @POST("device/off")
    suspend fun turnOffDevice(@Header("Authorization") token: String): DeviceResponse

    @GET("device/status")
    suspend fun getDeviceStatus(@Header("Authorization") token: String): DeviceStatus
}

data class DeviceResponse(
    val success: Boolean,
    val message: String
)

data class DeviceStatus(
    val isOn: Boolean,
    val lastUpdated: String
) 