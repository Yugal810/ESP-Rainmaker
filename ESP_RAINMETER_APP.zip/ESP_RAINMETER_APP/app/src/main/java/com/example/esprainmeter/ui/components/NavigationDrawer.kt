package com.example.esprainmeter.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.esprainmeter.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigationDrawer(
    drawerState: DrawerState,
    currentRoute: String,
    navController: NavController,
    onDrawerItemClick: (Screen) -> Unit,
    content: @Composable () -> Unit
) {
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(300.dp)
            ) {
                DrawerHeader()
                HorizontalDivider(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                )
                NavigationDrawerItems(
                    currentRoute = currentRoute,
                    onItemClick = onDrawerItemClick
                )
            }
        },
        content = content
    )
}

@Composable
fun DrawerHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                    )
                )
            )
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Cloud,
            contentDescription = "App Logo",
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onPrimary
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = "ESP Rainmeter",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onPrimary
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NavigationDrawerItems(
    currentRoute: String,
    onItemClick: (Screen) -> Unit
) {
    val items = listOf(
        NavigationItem(
            route = Screen.Devices.route,
            icon = Icons.Default.DeviceHub,
            label = "Devices"
        ),
        NavigationItem(
            route = Screen.Schedules.route,
            icon = Icons.Default.Schedule,
            label = "Schedules"
        ),
        NavigationItem(
            route = Screen.Scenes.route,
            icon = Icons.Default.Movie,
            label = "Scenes"
        ),

        NavigationItem(
            route = Screen.Settings.route,
            icon = Icons.Default.Settings,
            label = "Settings"
        )
    )

    items.forEach { item ->
        NavigationDrawerItem(
            icon = { Icon(item.icon, contentDescription = item.label) },
            label = { Text(item.label) },
            selected = currentRoute == item.route,
            onClick = { 
                Screen.fromRoute(item.route)?.let { screen ->
                    onItemClick(screen)
                }
            },
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
            colors = NavigationDrawerItemDefaults.colors(
                selectedContainerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f),
                selectedIconColor = MaterialTheme.colorScheme.secondary,
                selectedTextColor = MaterialTheme.colorScheme.onBackground
            )
        )
    }
}

data class NavigationItem(
    val route: String,
    val icon: ImageVector,
    val label: String
) 