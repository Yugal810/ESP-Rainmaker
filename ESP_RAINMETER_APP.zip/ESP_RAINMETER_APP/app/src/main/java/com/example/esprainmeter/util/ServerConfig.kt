package com.example.esprainmeter.util

object ServerConfig {
    // Default server URL - updated to match the running FastAPI server
    var serverUrl: String = "http://192.168.211.228:8000" // Your local IP address and port
    
    fun getBaseUrl(): String {
        return if (serverUrl.endsWith("/")) serverUrl else "$serverUrl/"
    }
} 