package com.example.esprainmeter.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.esprainmeter.components.DeviceType
import com.example.esprainmeter.components.DeviceCard // Corrected import if DeviceCard is used for preview
import com.example.esprainmeter.R // If you need R for resources
import com.example.esprainmeter.models.Device
import com.example.esprainmeter.models.Room
import com.example.esprainmeter.navigation.Screen
import com.example.esprainmeter.viewmodel.DeviceViewModel
import kotlinx.coroutines.launch
import java.net.URLDecoder
import java.util.*
import androidx.compose.runtime.State

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDeviceScreen(
    navController: NavController,
    qrCode: String?,
    deviceViewModel: DeviceViewModel = hiltViewModel()
) {
    val rooms by deviceViewModel.rooms.collectAsState()
    val decodedQr = remember(qrCode) { URLDecoder.decode(qrCode ?: "", "UTF-8") }
    val scope = rememberCoroutineScope()

    var deviceName by remember { mutableStateOf("") }
    var selectedRoom by remember { mutableStateOf<Room?>(null) }
    // var newRoomName by remember { mutableStateOf("") } // Removed, new rooms not added here
    // var isNewRoom by remember { mutableStateOf(false) } // Removed
    var showRoomMissingDialog by remember { mutableStateOf(false) }

    val deviceTypes = listOf("Light", "Fan", "Socket", "Other")
    var selectedDeviceType by remember { mutableStateOf(deviceTypes.first()) }
    var customDeviceType by remember { mutableStateOf("") }
    var deviceTypeExpanded by remember { mutableStateOf(false) }

    var roomExpanded by remember { mutableStateOf(false) }
    var showDeviceCard by remember { mutableStateOf(false) }
    var previewDevice by remember { mutableStateOf<Device?>(null) }

    val isFormValid by remember {
        derivedStateOf {
            deviceName.isNotBlank() &&
                    selectedRoom != null && // Must select an existing room
                    (selectedDeviceType != "Other" || customDeviceType.isNotBlank())
        }
    }

    LaunchedEffect(isFormValid, deviceName, selectedRoom, selectedDeviceType, customDeviceType) {
        if (isFormValid) {
            val finalDeviceType = if (selectedDeviceType == "Other") customDeviceType else selectedDeviceType
            previewDevice = Device(
                id = UUID.randomUUID().toString(),
                name = deviceName,
                roomId = selectedRoom?.id ?: "", // selectedRoom will not be null due to isFormValid
                type = finalDeviceType,
                isOn = false,
                qrValue = decodedQr
            )
            showDeviceCard = true
        } else {
            showDeviceCard = false
        }
    }

    if (showRoomMissingDialog) {
        AlertDialog(
            onDismissRequest = { showRoomMissingDialog = false },
            title = { Text("Room Required") },
            text = { Text("Please select an existing room for this device. If the room doesn't exist, please create it first from the main screen.") },
            confirmButton = {
                TextButton(onClick = { showRoomMissingDialog = false }) { Text("OK") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Add New Device") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = deviceName,
                onValueChange = { deviceName = it },
                label = { Text("Device Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // if (isNewRoom) { // Removed section for adding new room
            //     Row(verticalAlignment = Alignment.CenterVertically) {
            //         OutlinedTextField(
            //             value = newRoomName,
            //             onValueChange = { newRoomName = it },
            //             label = { Text("New Room Name") },
            //             modifier = Modifier.weight(1f)
            //         )
            //         IconButton(onClick = { isNewRoom = false; newRoomName = "" }) {
            //             Icon(Icons.Default.Close, contentDescription = "Cancel Add Room")
            //         }
            //     }
            // } else {
            ExposedDropdownMenuBox(
                expanded = roomExpanded,
                onExpandedChange = { roomExpanded = !roomExpanded }
            ) {
                OutlinedTextField(
                    value = selectedRoom?.name ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Select a Room") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = roomExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = roomExpanded,
                    onDismissRequest = { roomExpanded = false }
                ) {
                    if (rooms.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("No rooms available. Create one first.") },
                            onClick = { roomExpanded = false },
                            enabled = false
                        )
                    }
                    rooms.forEach { room ->
                        DropdownMenuItem(
                            text = { Text(room.name) },
                            onClick = {
                                selectedRoom = room
                                roomExpanded = false
                            }
                        )
                    }
                    // DropdownMenuItem( // Removed option to add new room from here
                    //     text = { Text("Add New Room...", color = MaterialTheme.colorScheme.primary) },
                    //     onClick = {
                    //         isNewRoom = true
                    //         selectedRoom = null
                    //         roomExpanded = false
                    //     },
                    //     leadingIcon = { Icon(Icons.Default.Add, contentDescription = "Add Room") }
                    // )
                }
            }
            // }

            Spacer(modifier = Modifier.height(16.dp))

            ExposedDropdownMenuBox(
                expanded = deviceTypeExpanded,
                onExpandedChange = { deviceTypeExpanded = !deviceTypeExpanded }
            ) {
                OutlinedTextField(
                    value = selectedDeviceType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Device Type") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deviceTypeExpanded) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = deviceTypeExpanded,
                    onDismissRequest = { deviceTypeExpanded = false }
                ) {
                    deviceTypes.forEach { type ->
                        DropdownMenuItem(
                            text = { Text(type) },
                            onClick = {
                                selectedDeviceType = type
                                deviceTypeExpanded = false
                            }
                        )
                    }
                }
            }

            if (selectedDeviceType == "Other") {
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = customDeviceType,
                    onValueChange = { customDeviceType = it },
                    label = { Text("Enter Custom Device Type") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            if (showDeviceCard && previewDevice != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Preview:", style = MaterialTheme.typography.titleMedium)
                DeviceCard(
                    device = previewDevice!!,
                    onToggleDevice = {},
                    onLongPress = {},
                    onClick = {}
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            Button(
                onClick = {
                    if (selectedRoom == null) {
                        showRoomMissingDialog = true
                    } else {
                        scope.launch {
                            try {
                                val finalDeviceType = if (selectedDeviceType == "Other") customDeviceType else selectedDeviceType
                                deviceViewModel.addDevice(
                                    device = previewDevice!!,
                                    roomName = selectedRoom!!.name
                                )
                                navController.popBackStack(Screen.Devices.route, false) // Changed from DevicesScreen to Screen.Devices.route
                            } catch (e: Exception) {
                                // Error is handled by the ViewModel's _operationError
                                // Optionally show a snackbar or dialog here too
                            }
                        }
                    }
                },
                enabled = isFormValid,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("ADD DEVICE")
            }
        }
    }
}

fun getIconForDeviceType(type: String): ImageVector {
    return DeviceType.fromString(type).icon
}

@Composable
fun EnhancedDeviceCard(device: Device) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = device.name,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = getIconForDeviceType(device.type),
                    contentDescription = "Device Type Icon",
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = device.type.replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.weight(1f))
                Switch(
                    checked = device.isOn,
                    onCheckedChange = null,
                    enabled = false
                )
            }
        }
    }
}