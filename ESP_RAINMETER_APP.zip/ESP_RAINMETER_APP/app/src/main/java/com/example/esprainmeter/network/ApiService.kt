package com.example.esprainmeter.network

import com.example.esprainmeter.config.ServerConfig
import com.example.esprainmeter.models.Device
import com.example.esprainmeter.models.Room
import com.example.esprainmeter.models.requests.DeviceRegisterRequest
import com.example.esprainmeter.models.requests.LoginRequest
import com.example.esprainmeter.models.responses.LoginResponse
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import javax.inject.Inject
import javax.inject.Singleton
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import com.google.gson.annotations.SerializedName

data class DeviceControlRequest(
    val device_id: String,
    val relay: String,
    val action: String
)

data class DeviceControlResponse(
    val msg: String
)

data class DeviceAddRequest(
    val device_id: String,
    val device_name: String,
    val room_name: String,
    val type: String? = null,
    val qr_value: String? = null
)

data class DeviceAddResponse(
    val msg: String
)

data class DeviceDeleteResponse(
    val message: String
)

data class AllDevicesResponse(
    val devices: List<Device>
)

data class DeviceStatusResponse(
    val device_id: String,
    val relay: String,
    val state: String,
    val last_updated: String,
    val is_online: Boolean
)

data class AllDevicesStatusResponse(
    val devices: List<DeviceStatusResponse>
)

// Room endpoints

data class RoomAddResponse(
    val message: String
)

data class RoomDeleteResponse(
    val message: String
)

@Singleton
class ApiService @Inject constructor(private val retrofit: Retrofit) {
    interface Api {
        @POST("/device/control")
        suspend fun controlDevice(
            @Body request: DeviceControlRequest,
            @Header("Authorization") token: String
        ): Response<DeviceControlResponse>
        
        @GET("/device/status/{device_id}")
        suspend fun getDeviceStatus(@Path("device_id") deviceId: String): Response<DeviceStatusResponse>
        
        @GET("/device/status")
        suspend fun getAllDevicesStatus(): Response<AllDevicesStatusResponse>
        
        // Device CRUD
        @POST("/device/add")
        suspend fun addDevice(
            @Body request: DeviceAddRequest,
            @Header("Authorization") token: String
        ): Response<DeviceAddResponse>

        @GET("/devices/all")
        suspend fun getAllDevices(
            @Header("Authorization") token: String
        ): Response<List<Device>>

        @DELETE("/device/delete/{device_id}")
        suspend fun deleteDevice(
            @Path("device_id") deviceId: String,
            @Header("Authorization") token: String
        ): Response<DeviceDeleteResponse>

        // Room CRUD
        @POST("/room/add")
        suspend fun addRoom(
            @Body room: Room,
            @Header("Authorization") token: String
        ): Response<RoomAddResponse>

        @GET("/rooms")
        suspend fun getRooms(
            @Header("Authorization") token: String
        ): Response<List<Room>>

        @DELETE("/room/delete/{room_name}")
        suspend fun deleteRoom(
            @Path("room_name") roomName: String,
            @Header("Authorization") token: String
        ): Response<RoomDeleteResponse>
        
        // Add your API endpoints here
        // Example:
        // @GET(ServerConfig.Endpoints.RAIN_DATA)
        // suspend fun getRainData(): Response<RainData>
    }

    val api: Api = retrofit.create(Api::class.java)
} 

interface AuthApiService {
    @FormUrlEncoded
    @POST("token")
    suspend fun login(
        @Field("username") username: String,
        @Field("password") password: String
    ): TokenResponse

    // Registration endpoint
    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("password") password: String
    ): TokenResponse // or a custom RegisterResponse if needed
}

data class TokenResponse(
    @SerializedName("access_token") val accessToken: String,
    @SerializedName("token_type") val tokenType: String
) 

interface ApiService {
    @POST("token")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @GET("devices/all")
    suspend fun getDevices(): List<Device>

    @GET("rooms")
    suspend fun getRooms(): List<Room>

    @POST("device/add")
    suspend fun addDevice(@Body request: DeviceRegisterRequest): Response<Unit>

    @DELETE("device/delete/{device_id}")
    suspend fun deleteDevice(@Path("device_id") deviceId: String): Response<Unit>
} 