package com.example.esprainmeter.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit,
    onNavigateToPrivacyPolicy: () -> Unit = {},
    onNavigateToTerms: () -> Unit = {},
    onNavigateToLicenses: () -> Unit = {},
    onNavigateToServerSettings: () -> Unit = {},
    navController: NavController,
    authViewModel: AuthViewModel
) {
    val context = LocalContext.current
    var notificationsEnabled by remember { mutableStateOf(true) }
    val settingsViewModel: SettingsViewModel = hiltViewModel()
    val serverUrl by settingsViewModel.serverUrl.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // User Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Account",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Logged in to ESP RainMaker",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // Preferences Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Preferences",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Push Notifications",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = { enabled ->
                            notificationsEnabled = enabled
                        }
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Divider()
                Spacer(modifier = Modifier.height(8.dp))

                // Server Settings
                TextButton(
                    onClick = onNavigateToServerSettings,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storage,
                            contentDescription = "Server Settings"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Server Settings")
                    }
                }
            }
        }

        // Server Connection Status (moved from DevicesScreen)
        val deviceViewModel: com.example.esprainmeter.viewmodel.DeviceViewModel = androidx.hilt.navigation.compose.hiltViewModel()
        val isLoading by deviceViewModel.isLoading.collectAsState()
        val error by deviceViewModel.error.collectAsState()
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (error != null) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = when {
                                isLoading -> Icons.Default.Sync
                                error != null -> Icons.Default.CloudOff
                                else -> Icons.Default.CloudDone
                            },
                            contentDescription = "Server Status",
                            tint = when {
                                isLoading -> MaterialTheme.colorScheme.primary
                                error != null -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                        Text(
                            text = when {
                                isLoading -> "Syncing with server..."
                                error != null -> "Connection error"
                                else -> "Connected to server"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (error != null) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                        }
                        TextButton(
                            onClick = { deviceViewModel.testServerConnection() },
                            enabled = !isLoading
                        ) {
                            Text("Test Connection")
                        }
                    }
                }
                // Show error message if there's an error
                error?.let { errorMessage ->
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // About Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "About",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                // Terms of Service
                TextButton(
                    onClick = onNavigateToTerms,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = "Terms of Service"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Terms of Service")
                    }
                }

                // Privacy Policy
                TextButton(
                    onClick = onNavigateToPrivacyPolicy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PrivacyTip,
                            contentDescription = "Privacy Policy"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Privacy Policy")
                    }
                }

                // Licenses
                TextButton(
                    onClick = onNavigateToLicenses,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Licenses"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Licenses")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Version info at the bottom
        Text(
            text = "Version 1.0.0",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )

        // Server Configuration
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Server Configuration", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = serverUrl,
                    onValueChange = { newValue ->
                        settingsViewModel.updateUrl(newValue)
                    },
                    label = { Text("Server URL") }
                )
                Button(onClick = { settingsViewModel.saveUrl() }) {
                    Text("Save URL")
                }
                Divider(modifier = Modifier.padding(vertical = 16.dp))
                Button(
                    onClick = { /* TODO: Implement QR code scanning here */ },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan QR")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Scan Server QR Code")
                }
            }
        }
    }
} 