package com.example.esprainmeter.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.esprainmeter.config.ServerConfig
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SERVER_URL = "server_url"
    }

    fun getServerUrl(): String {
        return prefs.getString(KEY_SERVER_URL, ServerConfig.BASE_URL) ?: ServerConfig.BASE_URL
    }

    fun setServerUrl(url: String) {
        prefs.edit().putString(KEY_SERVER_URL, url).apply()
    }
} 