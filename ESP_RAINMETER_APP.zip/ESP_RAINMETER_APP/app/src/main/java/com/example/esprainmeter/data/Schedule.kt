package com.example.esprainmeter.data

data class Schedule(
    val id: String = "",
    val deviceId: String = "",
    val deviceName: String = "",
    val hour: Int = 0,
    val minute: Int = 0,
    val days: List<String> = emptyList(),
    val isOn: Boolean = true,
    val isEnabled: Boolean = true
) 