package com.example.esprainmeter.models

// Represents a single smart device in the system.
data class Device(
    val id: String = "",       // Unique ID
    
    val name: String = "",     // User-defined name (e.g., "Desk Lamp")
    
    val roomId: String = "",   // ID of the room it belongs to
    
    val type: String = "",     // Type of device (e.g., "Light", "Fan")
    
    val qrValue: String = "",  // The scanned QR code value
    
    val isOn: Boolean = false  // Current state (on/off)
)
