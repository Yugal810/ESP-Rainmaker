package com.example.esprainmeter.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
// import androidx.compose.ui.res.painterResource // Only if using custom drawables for icons
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
// import com.example.esprainmeter.R // Import R if needed for resources like strings
import com.example.esprainmeter.components.DeviceCard
import com.example.esprainmeter.models.Device // Explicit import for Device model
import com.example.esprainmeter.models.Room
import com.example.esprainmeter.navigation.Screen
import com.example.esprainmeter.viewmodel.DeviceViewModel
import com.example.esprainmeter.viewmodel.UiState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
// Remove this line as it's included in the wildcard import above
// import androidx.compose.runtime.State
// Add these imports
import kotlinx.coroutines.flow.StateFlow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.animation.animateColorAsState
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.esprainmeter.components.DeviceType
import androidx.compose.material.icons.filled.Room
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.MoreVert
import com.example.esprainmeter.ui.theme.RainmakerTheme
import androidx.compose.material.ExperimentalMaterialApi
import androidx.activity.compose.rememberLauncherForActivityResult
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterialApi::class)
@Composable
fun DevicesScreen(
    navController: NavController,
    deviceViewModel: DeviceViewModel = hiltViewModel()
) {
    val rooms by deviceViewModel.rooms.collectAsState(initial = emptyList())
    val devicesState by deviceViewModel.devicesState.collectAsStateWithLifecycle()
    val isLoading by deviceViewModel.isLoading.collectAsStateWithLifecycle()
    val operationError: String? by deviceViewModel.operationError
    var deviceToDelete by remember { mutableStateOf<Device?>(null) }
    var showAddDeviceDialog by remember { mutableStateOf(false) }
    var scannedDeviceData by remember { mutableStateOf<Pair<String, String>?>(null) }

    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            val contents = result.contents
            if (contents.startsWith("ESP_DEVICE:")) {
                try {
                    val jsonStr = contents.substringAfter("ESP_DEVICE:")
                    val jsonObj = JSONObject(jsonStr)
                    val deviceId = jsonObj.getString("device_id")
                    val deviceType = jsonObj.getString("device_type")
                    scannedDeviceData = deviceId to deviceType
                    showAddDeviceDialog = true
                } catch (e: Exception) {
                    deviceViewModel.setOperationError("Invalid QR code format.")
                }
            } else {
                deviceViewModel.setOperationError("Not a valid ESP Rainmaker device QR code.")
            }
        }
    }

    if (showAddDeviceDialog && scannedDeviceData != null) {
        AddDeviceDialog(
            rooms = rooms,
            deviceType = scannedDeviceData!!.second,
            onDismiss = { showAddDeviceDialog = false },
            onConfirm = { deviceName, room ->
                val (deviceId, _) = scannedDeviceData!!
                deviceViewModel.addDevice(deviceId, deviceName, room.id ?: "")
                showAddDeviceDialog = false
            }
        )
    }

    val pullRefreshState = rememberPullRefreshState(
        refreshing = isLoading,
        onRefresh = { deviceViewModel.refreshData() }
    )

    // Handle operation errors with an AlertDialog
    operationError?.let { error ->
        AlertDialog(
            onDismissRequest = { deviceViewModel.clearOperationError() },
            title = { Text("Error") },
            text = { Text(error) },
            confirmButton = {
                TextButton(onClick = { deviceViewModel.clearOperationError() }) { Text("OK") }
            }
        )
    }

    // Dialog for confirming device deletion
    if (deviceToDelete != null) {
        AlertDialog(
            onDismissRequest = { deviceToDelete = null },
            title = { Text("Delete Device") },
            text = { Text("Are you sure you want to delete '${deviceToDelete?.name}'?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        deviceToDelete?.let { deviceViewModel.deleteDevice(it.id) }
                        deviceToDelete = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deviceToDelete = null }) { Text("Cancel") }
            }
        )
    }
    
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = {
                val options = ScanOptions()
                options.setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                options.setPrompt("Scan a device QR code")
                options.setCameraId(0) // Use a specific camera of the device
                options.setBeepEnabled(true)
                options.setBarcodeImageEnabled(true)
                scanLauncher.launch(options)
            }) {
                Icon(Icons.Filled.QrCodeScanner, contentDescription = "Scan Device")
            }
        }
    ) { paddingValues ->
        // The main content of the screen
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .pullRefresh(pullRefreshState)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (devicesState) {
                is UiState.Loading -> {
                    if (!isLoading) { // If not pull-to-refreshing, show central spinner
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    }
                }
                is UiState.Error -> {
                    val errorMessage = (devicesState as UiState.Error).message
                    RainMakerErrorState(errorMessage = errorMessage, onRetry = { deviceViewModel.refreshData() })
                }
                is UiState.Success -> {
                    val allDevices = (devicesState as UiState.Success<List<Device>>).data
                    
                    val validRooms = rooms.filter { !it.id.isNullOrBlank() }
                    val roomMap = validRooms.associateBy { it.id }

                    val devicesByRoom = allDevices
                        .filter { !it.roomId.isNullOrBlank() && it.roomId in roomMap }
                        .groupBy { roomMap[it.roomId]!! }

                    val unassignedDevices = allDevices.filter { it.roomId.isNullOrBlank() || it.roomId !in roomMap }

                    if (allDevices.isEmpty() && validRooms.isEmpty()) {
                        RainMakerEmptyState(hasRooms = false, selectedRoomName = null)
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            devicesByRoom.forEach { (room, devicesInRoom) ->
                                item(key = "room_header_${room.id}") {
                                    RoomHeader(room.name)
                                }
                                items(items = devicesInRoom, key = { "device_${it.id}" }) { device ->
                                    EnhancedDeviceCard(
                                        device = device,
                                        onToggleDevice = { newState ->
                                            if (!device.id.isNullOrBlank()) {
                                                deviceViewModel.toggleDeviceState(device.id, newState)
                                            }
                                        },
                                        onLongPress = { deviceToDelete = device },
                                        onClick = { /* Handle device click */ }
                                    )
                                }
                            }

                            if (unassignedDevices.isNotEmpty()) {
                                item(key = "unassigned_header") {
                                    RoomHeader("Unassigned Devices")
                                }
                                items(items = unassignedDevices, key = { "unassigned_${it.id}" }) { device ->
                                    EnhancedDeviceCard(
                                        device = device,
                                        onToggleDevice = { newState ->
                                            if (!device.id.isNullOrBlank()) {
                                                deviceViewModel.toggleDeviceState(device.id, newState)
                                            }
                                        },
                                        onLongPress = { deviceToDelete = device },
                                        onClick = { /* Handle device click */ }
                                    )
                                }
                            }
                        }
                    }
                }
            }
            PullRefreshIndicator(
                refreshing = isLoading,
                state = pullRefreshState,
                modifier = Modifier.align(Alignment.TopCenter),
                backgroundColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DeviceScreenTopBar(
    onAddRoom: () -> Unit,
    onRefresh: () -> Unit
) {
    TopAppBar(
        title = { Text("My Devices") },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        ),
        actions = {
            IconButton(onClick = onAddRoom) {
                Icon(Icons.Filled.Add, contentDescription = "Add Room")
            }
            IconButton(onClick = onRefresh) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh")
            }
        }
    )
}

@Composable
fun RoomHeader(name: String) {
    Text(
        text = name,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        modifier = Modifier.padding(bottom = 8.dp, top = 16.dp),
        color = MaterialTheme.colorScheme.primary
    )
}

@Composable
fun RainMakerErrorState(errorMessage: String, onRetry: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.CloudOff,
            contentDescription = "Error",
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.error
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Connection Error",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.error
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = errorMessage,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        TextButton(onClick = onRetry) { Text("Retry") }
    }
}

@Composable
fun EnhancedFilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: String,
    count: Int,
    icon: ImageVector
) {
    val backgroundColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        label = "Chip Background Color"
    )
    val textColor by animateColorAsState(
        targetValue = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
        label = "Chip Text Color"
    )

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = backgroundColor,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
        modifier = Modifier
            .height(40.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = "$label ($count)",
                color = textColor,
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

@Composable
fun EmptyDevicesState(
    hasRooms: Boolean,
    selectedRoomName: String?
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.DevicesOther,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Text(
                text = if (hasRooms) {
                    if (selectedRoomName != null) {
                        "No devices in $selectedRoomName"
                    } else {
                        "No devices found"
                    }
                } else {
                    "Add a room first, then add devices"
                },
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (hasRooms) {
                Text(
                    text = "Tap the + button to add your first device",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun EnhancedDevicesList(
    devices: List<Device>,
    onToggleDevice: (Device, Boolean) -> Unit,
    onLongPress: (Device) -> Unit,
    onClick: (Device) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        itemsIndexed(
            devices,
            key = { index, device -> if (device.id.isNotBlank()) device.id else index.toString() }
        ) { _, device ->
            EnhancedDeviceCard(
                device = device,
                onToggleDevice = { newState -> onToggleDevice(device, newState) },
                onLongPress = { onLongPress(device) },
                onClick = { onClick(device) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EnhancedDeviceCard(
    device: Device,
    onToggleDevice: (Boolean) -> Unit,
    onLongPress: () -> Unit,
    onClick: () -> Unit
) {
    val cardColor by animateColorAsState(
        targetValue = if (device.isOn) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        label = "Card Color"
    )

    // A valid ID is required to toggle the device state.
    val canBeToggled = !device.id.isNullOrBlank()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongPress
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = DeviceType.fromString(device.type).icon,
                    contentDescription = "Device Type",
                    modifier = Modifier.size(40.dp),
                    tint = if (device.isOn) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = device.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (device.isOn) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = device.type.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Switch(
                checked = device.isOn,
                onCheckedChange = onToggleDevice,
                enabled = canBeToggled, // The switch is disabled if the device has no valid ID
                thumbContent = {
                    if (device.isOn) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "On",
                            modifier = Modifier.size(SwitchDefaults.IconSize)
                        )
                    }
                }
            )
        }
    }
}

@Composable
fun RainMakerEmptyState(
    hasRooms: Boolean,
    selectedRoomName: String?
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.DevicesOther,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Text(
                text = if (hasRooms) {
                    if (selectedRoomName != null) {
                        "No devices in $selectedRoomName"
                    } else {
                        "No devices found"
                    }
                } else {
                    "Add a room first, then add devices"
                },
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (hasRooms) {
                Text(
                    text = "Tap the + button to add your first device",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun RainMakerDevicesList(
    devices: List<Device>,
    onToggleDevice: (Device, Boolean) -> Unit,
    onLongPress: (Device) -> Unit,
    onClick: (Device) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        itemsIndexed(
            devices,
            key = { index, device -> if (device.id.isNotBlank()) device.id else index.toString() }
        ) { _, device ->
            RainMakerDeviceCard(
                device = device,
                onToggleDevice = { newState -> onToggleDevice(device, newState) },
                onLongPress = { onLongPress(device) },
                onClick = { onClick(device) }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RainMakerDeviceCard(
    device: Device,
    onToggleDevice: (Boolean) -> Unit,
    onLongPress: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongPress
            ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            // Enhanced status indicator
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .fillMaxHeight()
                    .background(
                        color = if (device.isOn) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
                        },
                        shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
                    )
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Device icon with background
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .background(
                                color = if (device.isOn) {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = DeviceType.fromString(device.type).icon,
                            contentDescription = null,
                            tint = if (device.isOn) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = device.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = device.type.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Enhanced switch
                Switch(
                    checked = device.isOn,
                    onCheckedChange = onToggleDevice,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.primary,
                        checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                        uncheckedThumbColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        uncheckedTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                    )
                )
            }
        }
    }
}

@Composable
fun AddDeviceDialog(
    rooms: List<Room>,
    deviceType: String,
    onDismiss: () -> Unit,
    onConfirm: (String, Room) -> Unit
) {
    var deviceName by remember { mutableStateOf(TextFieldValue(deviceType)) }
    var expanded by remember { mutableStateOf(false) }
    var selectedRoom by remember { mutableStateOf(rooms.firstOrNull()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Device") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = deviceName,
                    onValueChange = { deviceName = it },
                    label = { Text("Device Name") },
                    singleLine = true
                )
                if (selectedRoom != null) {
                    Box {
                        OutlinedTextField(
                            value = selectedRoom!!.name,
                            onValueChange = { },
                            label = { Text("Room") },
                            readOnly = true,
                            trailingIcon = {
                                Icon(Icons.Filled.ArrowDropDown, "Select Room", Modifier.clickable { expanded = true })
                            }
                        )
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            rooms.forEach { room ->
                                DropdownMenuItem(
                                    text = { Text(room.name) },
                                    onClick = {
                                        selectedRoom = room
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Text("Please create a room first to add a device.")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedRoom != null) {
                        onConfirm(deviceName.text, selectedRoom!!)
                    }
                },
                enabled = deviceName.text.isNotBlank() && selectedRoom != null
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}



