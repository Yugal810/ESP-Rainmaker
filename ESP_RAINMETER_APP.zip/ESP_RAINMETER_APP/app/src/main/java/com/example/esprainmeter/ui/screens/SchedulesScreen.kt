package com.example.esprainmeter.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.esprainmeter.data.Schedule
import com.example.esprainmeter.models.Device
import com.example.esprainmeter.models.Room
import com.example.esprainmeter.navigation.Screen
import com.example.esprainmeter.viewmodel.DeviceViewModel
import com.example.esprainmeter.viewmodel.ScheduleViewModel
import com.example.esprainmeter.viewmodel.UiState
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.vector.ImageVector


data class RoomInfo(
    val id: String,
    val name: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchedulesScreen(
    navController: NavController,
    scheduleViewModel: ScheduleViewModel = hiltViewModel(),
    deviceViewModel: DeviceViewModel = hiltViewModel()
) {
    val schedules by scheduleViewModel.schedules.collectAsState()
    val isLoading by scheduleViewModel.isLoading.collectAsState()
    val error by scheduleViewModel.error.collectAsState()
    val devicesState by deviceViewModel.devicesState.collectAsState()

    // Refresh schedules on navigation
    LaunchedEffect(Unit) { scheduleViewModel.fetchSchedules() }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate(Screen.AddSchedule.route) },
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Schedule")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when {
                isLoading -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                error != null -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(error ?: "Unknown error") }
                schedules.isEmpty() -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No schedules yet. Tap '+' to add one.") }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(
                        schedules,
                        key = { index, schedule -> if (schedule.id.isNotBlank()) schedule.id else index.toString() }
                    ) { _, schedule ->
                        ScheduleItem(
                            schedule = schedule,
                            onToggle = { isEnabled ->
                                scheduleViewModel.updateSchedule(schedule.copy(isEnabled = isEnabled))
                            },
                            onEdit = { id ->
                                navController.navigate(Screen.EditSchedule.route + "/$id")
                            },
                            onDelete = { id ->
                                scheduleViewModel.deleteSchedule(id)
                            },
                            deviceIcon = getDeviceIcon(schedule.deviceName) // Helper for device icon
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun getDeviceIcon(deviceName: String): ImageVector {
    // Return an icon based on device name/type (customize as needed)
    return when {
        deviceName.contains("light", true) -> Icons.Default.Lightbulb
        deviceName.contains("fan", true) -> Icons.Default.Toys
        deviceName.contains("plug", true) -> Icons.Default.Power
        else -> Icons.Default.Devices
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScheduleItem(
    schedule: Schedule,
    onToggle: (Boolean) -> Unit,
    onEdit: (String) -> Unit,
    onDelete: (String) -> Unit,
    deviceIcon: ImageVector
) {
    val scope = rememberCoroutineScope()
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = {
            if (it == SwipeToDismissBoxValue.EndToStart) {
                scope.launch { onDelete(schedule.id) }
                true
            } else false
        }
    )

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromEndToStart = true,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.error, MaterialTheme.shapes.medium)
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(
                    Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = MaterialTheme.colorScheme.onError
                )
            }
        }
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onEdit(schedule.id) },
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Device icon
                Icon(
                    deviceIcon,
                    contentDescription = null,
                    modifier = Modifier.size(32.dp).padding(8.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                // Status indicator bar
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .height(48.dp)
                        .background(
                            color = if (schedule.isEnabled) {
                                if (schedule.isOn) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val formattedTime = remember(schedule.hour, schedule.minute) {
                        val h = if (schedule.hour == 0 || schedule.hour == 12) 12 else schedule.hour % 12
                        val ampm = if (schedule.hour < 12) "AM" else "PM"
                        String.format("%02d:%02d %s", h, schedule.minute, ampm)
                    }
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${schedule.deviceName} - Turns ${if (schedule.isOn) "On" else "Off"}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = schedule.days.joinToString(", ").ifEmpty { "No days set" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = schedule.isEnabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.secondary,
                        checkedTrackColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f),
                        uncheckedThumbColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        uncheckedTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                    )
                )
            }
        }
    }
} 