package com.example.esprainmeter.config

object UrlHolder {
    var url: String = ServerConfig.BASE_URL // Default value
} 