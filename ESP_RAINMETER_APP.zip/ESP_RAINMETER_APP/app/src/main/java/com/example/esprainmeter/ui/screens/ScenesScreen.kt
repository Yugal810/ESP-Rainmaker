package com.example.esprainmeter.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScenesScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Mock data for scenes - replace with ViewModel later
    val scenes = remember {
        listOf(
            Scene(id = "1", name = "Movie Night", icon = Icons.Default.Lightbulb, action = { /*TODO*/ }),
            Scene(id = "2", name = "Reading", icon = Icons.Default.Lightbulb, action = { /*TODO*/ })
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(onClick = { /* TODO: Navigate to Add Scene Screen */ }) {
                Icon(Icons.Default.Add, contentDescription = "Add Scene")
            }
        }
    ) { paddingValues ->
        if (scenes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                Text("No scenes yet", style = MaterialTheme.typography.headlineMedium)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(
                    scenes,
                    key = { index, scene -> if (scene.id.isNotBlank()) scene.id else index.toString() }
                ) { _, scene ->
                    SceneCard(scene = scene)
                }
            }
        }
    }
}

@Composable
fun SceneCard(scene: Scene) {
    var brightness by remember { mutableStateOf(0.5f) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(scene.icon, contentDescription = null, modifier = Modifier.size(40.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Text(text = scene.name, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Slider(
                value = brightness,
                onValueChange = { brightness = it },
                valueRange = 0f..1f
            )
        }
    }
}

// Dummy data class for Scene
data class Scene(
    val id: String,
    val name: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val action: () -> Unit
)
