package com.example.esprainmeter.ui.theme

import androidx.compose.ui.graphics.Color

// Friendly & Clean Theme
val FriendlyBlue = Color(0xFF1976D2)  // A pleasant, strong blue for primary actions
val FriendlyGreen = Color(0xFF388E3C)  // A calm green for success/on states
val FriendlyRed = Color(0xFFD32F2F)    // A clear red for warnings/off states

// Adaptive Surface & Background Colors
val LightBackground = Color(0xFFF7F9FC)
val LightSurface = Color.White
val DarkBackground = Color(0xFF121212)
val DarkSurface = Color(0xFF1E1E1E)

// Adaptive Text Colors
val LightText = Color(0xFF1A1A1A)
val DarkText = Color(0xFFEAEAEA)
val MutedText = Color(0xFF6C757D)

// Previous Theme Colors (can be removed later)
val TechBlue = Color(0xFF2196F3)
val TechBlueGlow = Color(0xFF64B5F6)
val TechGreen = Color(0xFF4CAF50)
val TechGreenGlow = Color(0xFF81C784)
val TechRed = Color(0xFFE57373)
val TechRedGlow = Color(0xFFEF9A9A)
val LightSurfaceVariant = Color(0xFFE0E0E0)
val DarkSurfaceVariant = Color(0xFF2D2D2D)
val LightTextPrimary = Color(0xFF212121)
val LightTextSecondary = Color(0xFF757575)
val DarkTextPrimary = Color(0xFFE0E0E0)
val DarkTextSecondary = Color(0xFFB0B0B0)
val GlowIntensityStrong = Color(0x40FFFFFF)
val GlowIntensityMedium = Color(0x20FFFFFF)
val GlowIntensityLight = Color(0x10FFFFFF)
val AppGreen = Color(0xFF4CAF50)
val AppOrange = Color(0xFFFF9800)

// Electric Blue & Coral Theme
val ElectricBlue = Color(0xFF0066FF)
val Coral = Color(0xFFFF6B6B)
val BrightCyan = Color(0xFF00D4FF)
val WarmCoral = Color(0xFFFF7A7A)
val SoftWhite = Color(0xFFF7F9FC)
val Charcoal = Color(0xFF222222)